public class Gabarito {
  public char respostaQuestao(int numeroQuestao) {
    /*
    * @author William Cardoso Barbosa
    * @see williancard123@gmail.com
    */
    switch (numeroQuestao) {
    case 1:
      return 'A';
    case 2:
      return 'B';
    case 3:
      return 'C';
    case 4:
      return 'D';
    case 5:
      return 'E';
    case 6:
      return 'A';
    case 7:
      return 'B';
    case 8:
      return 'C';
    case 9:
      return 'D';
    case 10:
      return 'E';
    case 11:
      return 'A';
    case 12:
      return 'B';
    case 13:
      return 'C';
    case 14:
      return 'D';
    case 15:
      return 'E';
    default:
      return ' ';
    }
  }
}
