/*
 * gabrielly cristine 
 * trab questao 13
 */
public class main {

	public static void main(String[] args) {
		float nota1=6, nota2=4, trabalho=7;
		
		Aluno al = new Aluno(nota1,nota2,trabalho);
		
		al.toString();
		
		System.out.println(al);		
		
	}

}
