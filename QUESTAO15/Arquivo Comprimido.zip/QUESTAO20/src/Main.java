
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main {

  public static void main(String[] args) {

    Cliente cliente = new Cliente();
    
   Venda vend =  new Venda();
    Passagem passagem = new Passagem(null, null, 0, null, null, cliente);
  }
}
