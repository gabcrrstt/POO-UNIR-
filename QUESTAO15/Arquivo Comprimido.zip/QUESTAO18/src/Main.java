
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Data dat = new Data(23, 4, 2021);
		Voo v = new Voo(null, 10, dat);
			
			
			System.out.println(v.toString());
	}

}
