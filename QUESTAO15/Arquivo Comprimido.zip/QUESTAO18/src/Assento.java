
public class Assento {
	private boolean vaga = true;
	
	public Assento() {
		
	}

	public boolean isVaga() {
		return vaga;
	}

	public void setVaga(boolean vaga) {
		this.vaga = vaga;
	}
	
	
}
